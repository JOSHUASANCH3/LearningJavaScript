# CRUD-Application

### [View the todo app here 🚀🚀🚀](https://crud-application-delta.vercel.app/)

## Font-Awesome CDN 
```
<link
   rel="stylesheet"
   href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
/>
```
